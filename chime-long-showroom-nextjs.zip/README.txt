Chime Long 3D showroom: add it to your Next.js project

1. Copy the folder  public/showroom  into your project's  public/  folder:
     your-project/public/showroom/index.html
     your-project/public/showroom/store.js
     your-project/public/showroom/data.js
     your-project/public/showroom/poster.jpg
     your-project/public/showroom/shoes/   (71 photos)

2. (Recommended) add the rewrite from next.config.example.js to your next.config,
   so the address is  yoursite.com/showroom .
   Without it, the address is  yoursite.com/showroom/index.html  (also works).

3. Link to it from your site, for example a "Visit the 3D showroom" button with href="/showroom".

4. Deploy (git push to Vercel as usual).

Notes
- It must be opened through a web address (your Vercel site or `npm run dev`), not by double-clicking
  index.html: browsers block the 3D code and photos when a page is opened from a file on disk.
- It loads three.js from cdn.jsdelivr.net and the font from Google Fonts, so the visitor needs internet.
- If you put it in a folder with a different name, change <base href="/showroom/"> in index.html to match.
- "See on the website" links go to /catalog?line=women (men, kids) on the same site.
