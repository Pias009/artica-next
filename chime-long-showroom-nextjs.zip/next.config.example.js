// Merge the rewrites() part into your existing next.config.js / next.config.mjs.
// It lets visitors open  yoursite.com/showroom  (without typing /index.html).
module.exports = {
  async rewrites() {
    return [{ source: '/showroom', destination: '/showroom/index.html' }];
  },
};
