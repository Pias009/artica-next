import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RectAreaLightUniformsLib } from 'three/addons/lights/RectAreaLightUniformsLib.js';
RectAreaLightUniformsLib.init();
try { await Promise.race([document.fonts.load('800 70px Manrope'), new Promise(r => setTimeout(r, 2500))]); } catch (e) {}

/* ------------------------------------------------------------------
   Chime Long 3D showroom. Same layout as the Blender scene:
   Blender (x, y, z) -> three (x, z, -y). Room 6 m wide, 7 m deep, 3.2 m high.
------------------------------------------------------------------- */
const CAT = window.CATALOG, UNITS = window.UNITS;
const RX = 3.0, RD = 7.0, RH = 3.2, EYE = 1.62;
const $ = s => document.querySelector(s);
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const mobile = matchMedia('(pointer: coarse)').matches || innerWidth < 760;
const SITE = '/catalog'; // your site's catalog page (same domain)

/* ---------- renderer / scene ---------- */
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, mobile ? 1.5 : 1.75));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.NeutralToneMapping;
renderer.toneMappingExposure = 0.92;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#E9E4DA');
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.22;

const camera = new THREE.PerspectiveCamera(mobile ? 70 : 62, innerWidth / innerHeight, 0.05, 50);
camera.rotation.order = 'YXZ';
camera.position.set(0, EYE, 1.6);

const lite = new URLSearchParams(location.search).has('lite');
let composer = null;
if (!mobile && !lite) {
  composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  const ao = new GTAOPass(scene, camera, innerWidth, innerHeight);
  ao.updateGtaoMaterial({ radius: 0.35, distanceExponent: 1.2, thickness: 1.2, scale: 1.0, samples: 12 });
  ao.blendIntensity = 0.85;
  composer.addPass(ao);
  composer.addPass(new OutputPass());
}

/* ---------- procedural textures ---------- */
function canvasTex(w, h, draw, repeat = [1, 1], srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat);
  t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const rnd = (a => () => (a = (a * 16807) % 2147483647) / 2147483647)(7);
function grain(g, x, y, w, h, base, lines, alpha) {
  for (let i = 0; i < lines; i++) {
    const yy = y + rnd() * h, amp = 1 + rnd() * 3;
    g.strokeStyle = `rgba(${base},${alpha * (0.4 + rnd() * 0.6)})`; g.lineWidth = 0.6 + rnd() * 1.4;
    g.beginPath(); g.moveTo(x, yy);
    for (let xx = x; xx <= x + w; xx += 24) g.lineTo(xx, yy + Math.sin(xx * 0.01 + i) * amp);
    g.stroke();
  }
}
// oak plank floor: 18 cm planks, random lengths, colour variation, fine gaps
const floorTex = canvasTex(1024, 1024, (g, w, h) => {
  g.fillStyle = '#B79C7C'; g.fillRect(0, 0, w, h);
  const rows = 8, rh = h / rows;
  for (let r = 0; r < rows; r++) {
    let x = -rnd() * 300;
    while (x < w) {
      const L = 260 + rnd() * 380, tone = rnd();
      const c = [178 + tone * 28, 152 + tone * 22, 122 + tone * 18].map(Math.round);
      g.fillStyle = `rgb(${c})`; g.fillRect(x, r * rh, L, rh);
      grain(g, x, r * rh, L, rh, '92,62,36', 14, 0.18);
      g.fillStyle = 'rgba(60,40,22,.55)'; g.fillRect(x, r * rh, 2, rh);
      x += L;
    }
    g.fillStyle = 'rgba(60,40,22,.5)'; g.fillRect(0, r * rh, w, 2);
  }
}, [3, 3.5]);
const oakTex = canvasTex(1024, 128, (g, w, h) => {
  g.fillStyle = '#D6C7B2'; g.fillRect(0, 0, w, h);
  grain(g, 0, 0, w, h, '120,88,58', 40, 0.16);
}, [1, 1]);
const plasterTex = canvasTex(512, 512, (g, w, h) => {
  g.fillStyle = '#E6E0D5'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 9000; i++) { g.fillStyle = `rgba(${rnd() > .5 ? '255,255,255' : '160,150,135'},${rnd() * 0.05})`; g.fillRect(rnd() * w, rnd() * h, 2, 2); }
}, [6, 2]);
const shadowTex = canvasTex(256, 128, (g, w, h) => {
  const gr = g.createRadialGradient(w / 2, h / 2, 2, w / 2, h / 2, w / 2);
  gr.addColorStop(0, 'rgba(20,16,10,.55)'); gr.addColorStop(0.45, 'rgba(20,16,10,.25)'); gr.addColorStop(1, 'rgba(20,16,10,0)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
}, [1, 1]);
shadowTex.wrapS = shadowTex.wrapT = THREE.ClampToEdgeWrapping;
const cornerTex = canvasTex(8, 256, (g, w, h) => {
  const gr = g.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, 'rgba(40,32,20,.28)'); gr.addColorStop(1, 'rgba(40,32,20,0)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
}, [1, 1]);
cornerTex.wrapS = cornerTex.wrapT = THREE.ClampToEdgeWrapping;

function textTex(text, { w = 2048, h = 160, size = 78, color = '#F3EFE6', bg = null, weight = 800, spacing = 10 } = {}) {
  return canvasTex(w, h, (g) => {
    if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
    g.fillStyle = color; g.font = `${weight} ${size}px Manrope, Arial, sans-serif`;
    g.textAlign = 'center'; g.textBaseline = 'middle';
    if ('letterSpacing' in g) g.letterSpacing = spacing + 'px';
    g.fillText(text, w / 2, h / 2 + 4);
  }, [1, 1]);
}

/* ---------- materials ---------- */
const M = {
  floor: new THREE.MeshPhysicalMaterial({ map: floorTex, roughness: 0.42, clearcoat: 0.35, clearcoatRoughness: 0.18 }),
  wall: new THREE.MeshStandardMaterial({ map: plasterTex, roughness: 0.95 }),
  ceil: new THREE.MeshStandardMaterial({ color: '#F4F2EE', roughness: 1, emissive: '#CFC9BE', emissiveIntensity: 0.55 }),
  panel: new THREE.MeshStandardMaterial({ color: '#CEC5B4', roughness: 0.9 }),
  oak: new THREE.MeshStandardMaterial({ map: oakTex, roughness: 0.48 }),
  olive: new THREE.MeshStandardMaterial({ color: '#474C38', roughness: 0.5 }),
  led: new THREE.MeshBasicMaterial({ color: '#FFF1D8' }),
  glow: new THREE.MeshBasicMaterial({ color: '#FFF6E8' }),
  riser: new THREE.MeshStandardMaterial({ color: '#E7E2D8', roughness: 0.35 }),
  fabric: new THREE.MeshStandardMaterial({ color: '#9DA38A', roughness: 1 }),
  rug: new THREE.MeshStandardMaterial({ color: '#C9BEA8', roughness: 1 }),
  pot: new THREE.MeshStandardMaterial({ color: '#D8D2C6', roughness: 0.7 }),
  leaf: new THREE.MeshStandardMaterial({ color: '#4E6B3A', roughness: 0.7, side: THREE.DoubleSide }),
};

function box(w, h, d, mat, x, y, z, { cast = true, receive = true } = {}) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z); m.castShadow = cast; m.receiveShadow = receive; scene.add(m); return m;
}
function plane(w, h, mat, x, y, z, ry = 0, rx = 0) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  m.position.set(x, y, z); m.rotation.set(rx, ry, 0, 'YXZ'); scene.add(m); return m;
}

/* ---------- room shell ---------- */
const floor = box(RX * 2 + 0.4, 0.1, RD + 2.4, M.floor, 0, -0.05, -RD / 2 + 1.0, { cast: false });
floor.name = 'floor';
box(RX * 2 + 0.4, 0.1, RD + 0.4, M.ceil, 0, RH + 0.05, -RD / 2, { cast: false });
const wallL = box(0.1, RH, RD + 0.4, M.wall, -RX - 0.05, RH / 2, -RD / 2, { cast: false });
const wallR = box(0.1, RH, RD + 0.4, M.wall, RX + 0.05, RH / 2, -RD / 2, { cast: false });
box(RX * 2 + 0.4, RH, 0.1, M.wall, 0, RH / 2, -RD - 0.05, { cast: false });
box(RX - 0.9, RH, 0.1, M.wall, -(RX + 0.9) / 2, RH / 2, 0.05, { cast: false });
box(RX - 0.9, RH, 0.1, M.wall, (RX + 0.9) / 2, RH / 2, 0.05, { cast: false });
box(1.8, RH - 2.4, 0.1, M.wall, 0, 2.4 + (RH - 2.4) / 2, 0.05, { cast: false });
// skirting + soft AO where walls meet the floor
box(0.02, 0.08, RD, M.olive, -RX + 0.01, 0.04, -RD / 2); box(0.02, 0.08, RD, M.olive, RX - 0.01, 0.04, -RD / 2);
box(RX * 2, 0.08, 0.02, M.olive, 0, 0.04, -RD + 0.01);
const aoMat = new THREE.MeshBasicMaterial({ map: cornerTex, transparent: true, depthWrite: false });
plane(RD, 0.5, aoMat, -RX + 0.002, 0.25, -RD / 2, Math.PI / 2);
plane(RD, 0.5, aoMat, RX - 0.002, 0.25, -RD / 2, -Math.PI / 2);
plane(RX * 2, 0.5, aoMat, 0, 0.25, -RD + 0.002, 0);
// brand on the entrance wall (seen when you turn around)
const brandTex = textTex('CHIME LONG', { color: '#474C38', size: 120, h: 200, spacing: 18 });
plane(2.2, 0.215, new THREE.MeshBasicMaterial({ map: brandTex, transparent: true }), -1.95, 1.85, -0.002, Math.PI);
const brandSub = textTex('WHOLESALE SHOWROOM  ·  FW26', { color: '#474C38', size: 56, h: 120, spacing: 12 });
plane(1.6, 0.094, new THREE.MeshBasicMaterial({ map: brandSub, transparent: true }), -1.95, 1.6, -0.002, Math.PI);

/* ---------- lights ---------- */
scene.add(new THREE.HemisphereLight('#FFF8F0', '#A39686', 0.38));
const downlights = [];
for (const x of [-1.6, 0, 1.6]) for (const yb of [1.4, 3.5, 5.6]) {
  const disc = new THREE.Mesh(new THREE.CircleGeometry(0.07, 32), M.glow);
  disc.rotation.x = Math.PI / 2; disc.position.set(x, RH - 0.004, -yb); scene.add(disc);
  const s = new THREE.SpotLight('#FFF4E8', 38, 7, THREE.MathUtils.degToRad(48), 0.85, 1.6);
  s.position.set(x, RH - 0.03, -yb); s.target.position.set(x * 1.35, 0, -yb); scene.add(s, s.target);
  downlights.push(s);
}
// only a few lights cast shadows, aimed at the three walls and the island
for (const [i, tx, tz] of [[0, -3, -3.5], [6, 3, -3.5], [5, 0, -7], [4, 0, -3.5]]) {
  const s = downlights[i]; s.castShadow = true; s.shadow.mapSize.set(mobile ? 512 : 1024, mobile ? 512 : 1024);
  s.shadow.bias = -0.0004; s.shadow.normalBias = 0.02; s.shadow.radius = 4; s.target.position.set(tx, 0.8, tz);
}
const ceilingFill = new THREE.RectAreaLight('#FFF3E4', 1.1, 5, 6);
ceilingFill.position.set(0, RH - 0.05, -3.5); ceilingFill.lookAt(0, 0, -3.5); scene.add(ceilingFill);

/* ---------- shelving units ---------- */
// frame(wall): origin on the wall surface, along = reading direction, out = into the room, ry = facing
function frame(wall, start) {
  if (wall === 'left') return { o: new THREE.Vector3(-RX, 0, -start), al: new THREE.Vector3(0, 0, -1), out: new THREE.Vector3(1, 0, 0), ry: Math.PI / 2 };
  if (wall === 'right') return { o: new THREE.Vector3(RX, 0, -start), al: new THREE.Vector3(0, 0, 1), out: new THREE.Vector3(-1, 0, 0), ry: -Math.PI / 2 };
  return { o: new THREE.Vector3(start, 0, -RD), al: new THREE.Vector3(1, 0, 0), out: new THREE.Vector3(0, 0, 1), ry: 0 };
}
const P = (f, a, o, y) => f.o.clone().addScaledVector(f.al, a).addScaledVector(f.out, o).setY(y);
function fbox(f, la, lo, h, mat, a, o, y, opts) {
  const sx = Math.abs(f.al.x) * la + Math.abs(f.out.x) * lo, sz = Math.abs(f.al.z) * la + Math.abs(f.out.z) * lo;
  const p = P(f, a, o, y); return box(sx, h, sz, mat, p.x, p.y, p.z, opts);
}
for (const [wall, u] of Object.entries(UNITS)) {
  const f = frame(wall, u.start), L = u.L;
  fbox(f, L, 0.024, 2.4, M.panel, L / 2, 0.012, 1.3, { cast: false });
  fbox(f, L, 0.34, 0.1, M.olive, L / 2, 0.17, 0.05);
  u.levels.forEach(z => {
    fbox(f, L, 0.32, 0.028, M.oak, L / 2, 0.17, z);
    fbox(f, L - 0.06, 0.012, 0.004, M.led, L / 2, 0.30, z - 0.016, { cast: false, receive: false });
  });
  for (let b = 0; b <= u.bays; b++) fbox(f, 0.03, 0.34, 2.4, M.oak, b * L / u.bays, 0.17, 1.3);
  fbox(f, L, 0.06, 0.26, M.olive, L / 2, 0.03, 2.63);
  const t = textTex(u.title, { size: 70, spacing: 14 });
  const tp = P(f, L / 2, 0.0615, 2.63);
  plane(L * 0.9, L * 0.9 * 160 / 2048, new THREE.MeshBasicMaterial({ map: t, transparent: true }), tp.x, tp.y, tp.z, f.ry);
  const mq = textTex('MOQ 300 PAIRS  ·  12 PER CASE', { color: '#474C38', size: 44, h: 110, spacing: 10, w: 1600 });
  const mp = P(f, L / 2, 0.025, 2.40);
  plane(1.6, 0.11, new THREE.MeshBasicMaterial({ map: mq, transparent: true }), mp.x, mp.y, mp.z, f.ry);
  // warm wash from the shelf LEDs
  const wash = new THREE.RectAreaLight('#FFF5EA', 1.5, L, 1.9);
  const wp = P(f, L / 2, 0.9, 1.3); wash.position.copy(wp);
  wash.lookAt(P(f, L / 2, 0, 1.3)); scene.add(wash);
}

/* ---------- island, seats, rug, plants ---------- */
const IZ = -3.5;
box(1.5, 0.70, 0.62, M.olive, 0, 0.35, IZ);
box(1.8, 0.05, 0.82, M.oak, 0, 0.725, IZ);
for (const x of [-0.45, 0.45]) box(0.62, 0.06, 0.38, M.riser, x, 0.78, IZ + 0.05);
plane(0.5, 0.1, new THREE.MeshBasicMaterial({ map: textTex('MEN', { size: 110, h: 220, w: 1100, spacing: 26 }), transparent: true }), 0, 0.45, IZ + 0.312, 0);
plane(0.7, 0.07, new THREE.MeshBasicMaterial({ map: textTex('US 7–13  ·  MOQ 300', { size: 60, h: 120, w: 1200, spacing: 10 }), transparent: true }), 0, 0.34, IZ + 0.312, 0);
const islandSpot = new THREE.SpotLight('#FFEBD6', 70, 6, THREE.MathUtils.degToRad(24), 0.6, 1.4);
islandSpot.position.set(0, RH - 0.05, IZ + 0.6); islandSpot.target.position.set(0, 0.8, IZ); scene.add(islandSpot, islandSpot.target);
for (const [x, yb] of [[-1.25, 2.1], [1.25, 2.1], [-1.25, 5.1], [1.25, 5.1]]) {
  const o = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.42, 48), M.fabric);
  o.position.set(x, 0.21, -yb); o.castShadow = o.receiveShadow = true; scene.add(o);
}
const rug = box(3.2, 0.012, 4.6, M.rug, 0, 0.006, -3.6, { cast: false });
for (const [x, z] of [[-2.62, -6.62], [2.62, -6.62]]) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.17, 0.5, 40), M.pot); pot.position.set(x, 0.25, z); pot.castShadow = true; scene.add(pot);
  const leafGeo = new THREE.SphereGeometry(0.16, 10, 8); leafGeo.scale(1, 0.35, 0.5);
  for (let i = 0; i < 26; i++) {
    const l = new THREE.Mesh(leafGeo, M.leaf), a = rnd() * Math.PI * 2, r = 0.05 + rnd() * 0.22, y = 0.55 + rnd() * 0.75;
    l.position.set(x + Math.cos(a) * r, y, z + Math.sin(a) * r); l.rotation.set(rnd() * 1.2 - 0.6, a, rnd() * 0.8 - 0.4);
    l.castShadow = true; scene.add(l);
  }
}

/* ---------- shoes ---------- */
const loader = new THREE.TextureLoader();
const manager = THREE.DefaultLoadingManager;
const BASE_W = { men: 0.30, women: 0.26, kids: 0.21 };
const pickables = [], pairs = [], bySlug = {};
const texCache = {};
function tex(img) {
  if (!texCache[img]) {
    const t = loader.load(`shoes/${img}.webp`); t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8; texCache[img] = t;
  }
  return texCache[img];
}
const shadowMat = new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 });

function shoeMesh(img, w, h, mirror) {
  const g = new THREE.PlaneGeometry(w, h); g.translate(0, h / 2, 0);
  // the photo already carries studio light, so show it as photographed (true product colour)
  const m = new THREE.MeshBasicMaterial({ map: tex(img), alphaTest: 0.45, side: THREE.DoubleSide, color: '#F4F1EA' });
  const mesh = new THREE.Mesh(g, m); mesh.castShadow = true; mesh.receiveShadow = false;
  if (mirror) mesh.scale.x = -1;
  // a darker twin 6 mm behind gives the photo a sense of thickness from an angle
  const back = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: tex(img), alphaTest: 0.45, color: '#2a2722', side: THREE.DoubleSide }));
  back.position.z = -0.006; mesh.add(back);
  return mesh;
}

function placePair(d, pos, ry, sScale = 1) {
  let w = BASE_W[d.line] * sScale, h = w * d.img_size[1] / d.img_size[0];
  const cap = d.category === 'Tall boots' ? 0.40 : 0.34;
  if (h > cap) { w *= cap / h; h = cap; }
  const g = new THREE.Group(); g.position.copy(pos); g.rotation.y = ry; scene.add(g);
  const a = shoeMesh(d.img, w, h, false); a.position.set(-w * 0.18, 0, 0.03); a.rotation.y = THREE.MathUtils.degToRad(-8);
  let b;
  if (d.img2) { let w2 = w, h2 = w2 * d.img2_size[1] / d.img2_size[0]; if (h2 > cap) { w2 *= cap / h2; h2 = cap; } b = shoeMesh(d.img2, w2, h2, false); }
  else b = shoeMesh(d.img, w, h, true);
  b.position.set(w * 0.30, 0, -0.05); b.rotation.y = THREE.MathUtils.degToRad(9);
  const s = new THREE.Mesh(new THREE.PlaneGeometry(w * 1.5, 0.24), shadowMat);
  s.rotation.x = -Math.PI / 2; s.position.set(w * 0.05, 0.0015, -0.01);
  const inner = new THREE.Group(); inner.add(a, b, s); g.add(inner);
  a.userData.slug = b.userData.slug = d.slug; pickables.push(a, b);
  const rec = { d, g, inner, baseRy: ry, w, h, lift: 0, hover: false };
  pairs.push(rec); bySlug[d.slug] = rec;
  return rec;
}
function labelAt(d, f, a, y) {
  const t = textTex(d.name.toUpperCase(), { color: '#2B2D24', size: 64, h: 110, w: 900, spacing: 8 });
  const p = P(f, a, 0.3315, y);
  plane(0.3, 0.0367, new THREE.MeshBasicMaterial({ map: t, transparent: true }), p.x, p.y, p.z, f.ry);
}

// same placement rules as the Blender scene
for (const [wall, u] of Object.entries(UNITS)) {
  const items = CAT.filter(d => d.wall === wall);
  const tall = items.filter(d => d.category === 'Tall boots'), rest = items.filter(d => d.category !== 'Tall boots');
  const lv = u.levels, n = lv.length;
  let counts = lv.map((_, i) => Math.floor(rest.length / n) + (i < rest.length % n ? 1 : 0));
  if (tall.length) counts = [...Array(n - 1)].map((_, i) => Math.floor(rest.length / (n - 1)) + (i < rest.length % (n - 1) ? 1 : 0)).concat([0]);
  const seq = rest.slice(), per = {};
  [...lv.keys()].sort((i, j) => Math.abs(lv[i] - 1.3) - Math.abs(lv[j] - 1.3)).forEach(li => { per[li] = seq.splice(0, Math.min(counts[li], seq.length)); });
  if (tall.length) per[n - 1] = tall.concat(per[n - 1] || []);
  const f = frame(wall, u.start), bw = u.L / u.bays;
  for (const [li, its] of Object.entries(per)) {
    if (!its.length) continue;
    const y = lv[li] + 0.0145, bc = Array(u.bays).fill(0);
    its.forEach((_, i) => bc[Math.floor(i * u.bays / its.length)]++);
    let k = 0;
    bc.forEach((c, bi) => { for (let j = 0; j < c; j++) {
      const a = bi * bw + (j + 0.5) * bw / c;
      const d = its[k++]; d._shelf = `${wall}:${li}`;
      placePair(d, P(f, a, 0.15, y), f.ry); labelAt(d, f, a, lv[li]);
    } });
  }
}
CAT.filter(d => d.wall === 'island').forEach((d, i) => placePair(d, new THREE.Vector3(i ? 0.45 : -0.45, 0.8105, IZ + 0.02), 0, 1.05));

/* ---------- first-person controls ---------- */
const state = { yaw: 0, pitch: -0.04, pos: camera.position.clone(), target: null, tween: null, entered: false, keys: {} };
const bounds = { x0: -RX + 0.65, x1: RX - 0.65, z0: -RD + 0.75, z1: -0.25 };
const islandBox = { x0: -1.15, x1: 1.15, z0: IZ - 0.68, z1: IZ + 0.68 };
function clampPos(p) {
  p.x = THREE.MathUtils.clamp(p.x, bounds.x0, bounds.x1); p.z = THREE.MathUtils.clamp(p.z, bounds.z0, bounds.z1);
  if (p.x > islandBox.x0 && p.x < islandBox.x1 && p.z > islandBox.z0 && p.z < islandBox.z1) {
    const dx = Math.min(p.x - islandBox.x0, islandBox.x1 - p.x), dz = Math.min(p.z - islandBox.z0, islandBox.z1 - p.z);
    if (dx < dz) p.x = p.x - islandBox.x0 < islandBox.x1 - p.x ? islandBox.x0 : islandBox.x1;
    else p.z = p.z - islandBox.z0 < islandBox.z1 - p.z ? islandBox.z0 : islandBox.z1;
  }
  return p;
}
const VIEWS = {
  entrance: { pos: [0, -0.6], yaw: 0, pitch: -0.05 },
  left: { pos: [-1.05, -3.6], yaw: Math.PI / 2, pitch: -0.06 },
  front: { pos: [0, -5.25], yaw: 0, pitch: -0.05 },
  right: { pos: [1.05, -3.6], yaw: -Math.PI / 2, pitch: -0.1 },
  island: { pos: [0, -2.05], yaw: 0, pitch: -0.42 },
};
function flyTo(px, pz, yaw, pitch, dur = 1.4) {
  const from = { x: state.pos.x, z: state.pos.z, yaw: state.yaw, pitch: state.pitch };
  let dy = yaw - from.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy));
  state.tween = { from, to: { x: px, z: pz, yaw: from.yaw + dy, pitch }, t: 0, dur: reduce ? 0.01 : dur };
}
function walkTo(p) {
  const q = clampPos(p.clone());
  const d = Math.hypot(q.x - state.pos.x, q.z - state.pos.z);
  state.tween = { from: { x: state.pos.x, z: state.pos.z, yaw: state.yaw, pitch: state.pitch }, to: { x: q.x, z: q.z, yaw: state.yaw, pitch: state.pitch }, t: 0, dur: reduce ? 0.01 : Math.min(2.2, 0.5 + d * 0.45) };
}
document.querySelectorAll('#views button').forEach(b => b.addEventListener('click', () => {
  const v = VIEWS[b.dataset.view]; flyTo(v.pos[0], v.pos[1], v.yaw, v.pitch);
  document.querySelectorAll('#views button').forEach(x => x.setAttribute('aria-pressed', x === b));
}));

// pointer: drag = look, click = walk or open
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
let down = null, hovered = null;
canvas.addEventListener('pointerdown', e => { down = { x: e.clientX, y: e.clientY, yaw: state.yaw, pitch: state.pitch, moved: false }; canvas.setPointerCapture(e.pointerId); });
canvas.addEventListener('pointermove', e => {
  if (down) {
    const dx = e.clientX - down.x, dy = e.clientY - down.y;
    if (Math.hypot(dx, dy) > 5) { down.moved = true; canvas.classList.add('drag'); state.tween = null; hideHint(); }
    if (down.moved) {
      const k = (mobile ? 0.0055 : 0.0035);
      state.yaw = down.yaw + dx * k; state.pitch = THREE.MathUtils.clamp(down.pitch + dy * k, -1.0, 0.6);
    }
  } else hoverAt(e.clientX, e.clientY);
});
canvas.addEventListener('pointerup', e => {
  canvas.classList.remove('drag');
  if (down && !down.moved) clickAt(e.clientX, e.clientY);
  down = null;
});
canvas.addEventListener('pointerleave', () => { setHover(null); });
function pick(x, y, objs) {
  ndc.set(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1); ray.setFromCamera(ndc, camera);
  return ray.intersectObjects(objs, false)[0];
}
const tip = $('#tip');
function hoverAt(x, y) {
  const h = pick(x, y, pickables);
  setHover(h ? bySlug[h.object.userData.slug] : null);
  if (hovered) { tip.innerHTML = `${hovered.d.name}<em>${hovered.d.type} · open</em>`; tip.style.left = x + 'px'; tip.style.top = y + 'px'; }
}
function setHover(rec) {
  if (hovered === rec) return;
  if (hovered) hovered.hover = false;
  hovered = rec; if (rec) rec.hover = true;
  canvas.classList.toggle('hot', !!rec); tip.classList.toggle('on', !!rec);
}
function clickAt(x, y) {
  const s = pick(x, y, pickables);
  if (s) { openPage(s.object.userData.slug); return; }
  const f = pick(x, y, [floor, rug]);
  if (f) walkTo(new THREE.Vector3(f.point.x, 0, f.point.z));
}
addEventListener('keydown', e => { if (!$('#page').classList.contains('on')) state.keys[e.key.toLowerCase()] = true; });
addEventListener('keyup', e => { state.keys[e.key.toLowerCase()] = false; });
addEventListener('wheel', e => { if (!state.entered || $('#page').classList.contains('on')) return; const f = new THREE.Vector3(-Math.sin(state.yaw), 0, -Math.cos(state.yaw)); state.pos.addScaledVector(f, -e.deltaY * 0.0025); clampPos(state.pos); state.tween = null; }, { passive: true });

let hintTimer;
function hideHint() { $('#hint').classList.add('off'); }

/* ---------- minimap ---------- */
const map = $('#map');
map.innerHTML = `
  <rect x="-3" y="0" width="6" height="7" rx=".15" fill="#ECE8E0" stroke="#474C38" stroke-width=".06"/>
  <rect x="-3" y="1" width=".34" height="5.2" fill="#C79E70"/><rect x="2.66" y="0.8" width=".34" height="5.2" fill="#C79E70"/>
  <rect x="-2.7" y="6.66" width="5.4" height=".34" fill="#C79E70"/><rect x="-.9" y="3.09" width="1.8" height=".82" rx=".06" fill="#474C38"/>
  <path d="M-.9 0h1.8" stroke="#ECE8E0" stroke-width=".12"/>
  <g id="me"><path d="M0 -.42 L.26 .2 L0 .08 L-.26 .2Z" fill="#B3202A"/></g>`;
const me = map.querySelector('#me');

/* ---------- loop ---------- */
const clock = new THREE.Clock();
const perf = { n: 0, t: 0 };
const tmp = new THREE.Vector3();
function frameLoop() {
  const dt = Math.min(0.05, clock.getDelta());
  if (state.tween) {
    const tw = state.tween; tw.t += dt / tw.dur; const k = tw.t >= 1 ? 1 : 1 - Math.pow(1 - tw.t, 3);
    state.pos.x = THREE.MathUtils.lerp(tw.from.x, tw.to.x, k); state.pos.z = THREE.MathUtils.lerp(tw.from.z, tw.to.z, k);
    state.yaw = THREE.MathUtils.lerp(tw.from.yaw, tw.to.yaw, k); state.pitch = THREE.MathUtils.lerp(tw.from.pitch, tw.to.pitch, k);
    if (tw.t >= 1) state.tween = null;
  }
  const K = state.keys, sp = (K.shift ? 3.2 : 1.7) * dt;
  const fw = (K.w || K.arrowup ? 1 : 0) - (K.s || K.arrowdown ? 1 : 0), st = (K.d ? 1 : 0) - (K.a ? 1 : 0);
  if (K.arrowleft) state.yaw += 1.6 * dt; if (K.arrowright) state.yaw -= 1.6 * dt;
  if (fw || st) {
    state.tween = null; hideHint();
    state.pos.x += (-Math.sin(state.yaw) * fw + Math.cos(state.yaw) * st) * sp;
    state.pos.z += (-Math.cos(state.yaw) * fw - Math.sin(state.yaw) * st) * sp;
    clampPos(state.pos);
  }
  // gentle head bob while moving makes walking feel physical
  const moving = state.tween || fw || st;
  state.bob = (state.bob || 0) + (moving && !reduce ? dt * 9 : 0);
  camera.position.set(state.pos.x, EYE + (moving && !reduce ? Math.sin(state.bob) * 0.012 : 0), state.pos.z);
  camera.rotation.set(state.pitch, state.yaw, 0);

  // shoes turn a little toward you (max 22°) and lift when hovered
  for (const r of pairs) {
    tmp.subVectors(camera.position, r.g.position);
    const want = Math.atan2(tmp.x, tmp.z);
    let dlt = want - r.baseRy; dlt = Math.atan2(Math.sin(dlt), Math.cos(dlt));
    dlt = THREE.MathUtils.clamp(dlt, -0.38, 0.38) * 0.6;
    r.inner.rotation.y += (dlt - r.inner.rotation.y) * Math.min(1, dt * 4);
    r.lift += ((r.hover ? 0.025 : 0) - r.lift) * Math.min(1, dt * 10);
    r.inner.position.y = r.lift;
  }
  me.setAttribute('transform', `translate(${state.pos.x} ${-state.pos.z}) rotate(${-state.yaw * 180 / Math.PI})`);
  if (composer) composer.render(); else renderer.render(scene, camera);
  // drop ambient occlusion on slow devices so walking stays smooth
  if (composer && state.entered) { perf.n++; perf.t += dt; if (perf.n === 90) { if (perf.t / perf.n > 1 / 32) { composer = null; } } }
  requestAnimationFrame(frameLoop);
}

/* ---------- loading + entrance ---------- */
manager.onProgress = (_, l, t) => { $('#bar').style.width = (l / t * 100) + '%'; };
manager.onLoad = () => {
  const b = $('#enter'); b.disabled = false; b.textContent = 'Enter the showroom';
};
$('#enter').addEventListener('click', () => {
  $('#loader').classList.add('done'); state.entered = true;
  flyTo(0, -0.6, 0, -0.05, 2.4);
  hintTimer = setTimeout(hideHint, 9000);
  if (location.hash.length > 1 && bySlug[location.hash.slice(1)]) setTimeout(() => openPage(location.hash.slice(1)), 900);
});
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight); if (composer) composer.setSize(innerWidth, innerHeight);
});
requestAnimationFrame(frameLoop);

/* ---------- shoe page ---------- */
const RUNS = {
  men: [['7', 1], ['8', 2], ['9', 2], ['10', 3], ['11', 2], ['12', 1], ['13', 1]],
  women: [['5', 1], ['6', 2], ['7', 3], ['8', 3], ['9', 2], ['10', 1]],
  kids: [['11', 1], ['12', 2], ['13', 2], ['1', 3], ['2', 2], ['3', 1], ['4', 1]],
};
const SIZE_LABEL = { men: 'US 7–13', women: 'US 5–10', kids: 'Youth 11–4' };
const WALL_NAME = { left: 'Women · Boots wall', front: 'Women · Shoes wall', right: 'Kids wall', island: 'Men · Centre table' };
const cart = new Map();
const page = $('#page'), pInfo = $('#pInfo'), pImg = $('#pImg'), pThumbs = $('#pThumbs');
const icon = n => `<svg class="i"><use href="#i-${n}"/></svg>`;
function openPage(slug) {
  const r = bySlug[slug]; if (!r) return; const d = r.d;
  const views = [[d.img, false], d.img2 ? [d.img2, false] : [d.img, true]];
  const show = i => { pImg.src = `shoes/${views[i][0]}.webp`; pImg.classList.toggle('flip', views[i][1]); pImg.alt = d.desc; pThumbs.querySelectorAll('button').forEach((b, k) => b.setAttribute('aria-current', k === i)); };
  pThumbs.innerHTML = views.map(([img, fl], i) => `<button aria-label="View ${i + 1}"><img src="shoes/${img}.webp" alt="" style="${fl ? 'transform:scaleX(-1)' : ''}"></button>`).join('');
  pThumbs.querySelectorAll('button').forEach((b, i) => b.addEventListener('click', () => show(i)));
  show(0);
  const specs = [['Upper', d.upper], ['Lining', d.lining], ['Warmth', (d.tags || []).includes('insulated') ? 'Insulated' : null], ['Water', (d.tags || []).includes('waterproof') ? 'Water-resistant' : null], ['Closure', d.closure], ['Outsole', d.sole], ['Heel', d.heel], ['Color', d.color]].filter(s => s[1]);
  const run = RUNS[d.line], max = Math.max(...run.map(r => r[1]));
  const mates = pairs.filter(p => p.d._shelf && p.d._shelf === d._shelf && p.d.slug !== d.slug || (d.wall === 'island' && p.d.wall === 'island' && p.d.slug !== d.slug));
  const inList = cart.has(slug);
  pInfo.innerHTML = `
    <span class="crumbs">${d.line} · ${d.category}${d.badge ? ' · ' + d.badge : ''}</span>
    <h2 id="pName">${d.name}</h2>
    <p class="p-type">${d.type}</p>
    <p class="p-desc">${d.desc}.</p>
    <div class="trio"><div><b>300</b><span>Pairs MOQ</span></div><div><b>12</b><span>Pairs / case</span></div><div><b>10d</b><span>Samples</span></div><div><b>45d</b><span>Production</span></div></div>
    <div><p class="lbl">Details</p><div class="specs">${specs.map(([k, v]) => `<div><small>${k}</small><b>${v}</b></div>`).join('')}</div></div>
    <div><p class="lbl">Case pack · ${SIZE_LABEL[d.line]} · pairs per size in one case</p>
      <div class="run">${run.map(([s, q], i) => `<div><em>${q}</em><i style="height:${q / max * 56}px;animation-delay:${i * 50}ms"></i><small>${s}</small></div>`).join('')}</div></div>
    <div class="sw"><i style="background:${d.hex}"></i>${d.color}<span style="color:var(--muted)">· more colors on request</span></div>
    <div class="p-actions">
      <button class="btn btn-dark" id="pAdd">${inList ? icon('check') + ' In inquiry list' : icon('plus') + ' Add to inquiry list'}</button>
      <button class="btn btn-ghost" id="pSample">Request sample</button>
    </div>
    <a class="link" href="${SITE}?line=${d.line}" target="_blank" rel="noopener">See ${d.line}'s line on the website ${icon('ext')}</a>
    ${mates.length ? `<div><p class="lbl">Also on this shelf · ${WALL_NAME[d.wall]}</p><div class="shelf-mates">${mates.map(m => `<button data-slug="${m.d.slug}"><span><img src="shoes/${m.d.img}.webp" alt=""></span><b>${m.d.name}</b></button>`).join('')}</div></div>` : ''}`;
  $('#pAdd').addEventListener('click', () => { toggleCart(slug); $('#pAdd').innerHTML = cart.has(slug) ? icon('check') + ' In inquiry list' : icon('plus') + ' Add to inquiry list'; });
  $('#pSample').addEventListener('click', () => { if (!cart.has(slug)) toggleCart(slug); openDrawer(); });
  pInfo.querySelectorAll('.shelf-mates button').forEach(b => b.addEventListener('click', () => openPage(b.dataset.slug)));
  pInfo.scrollTop = 0;
  page.classList.add('on'); page.setAttribute('aria-hidden', 'false');
  try { history.replaceState(null, '', '#' + slug); } catch (e) {}
  setHover(null); state.keys = {};
  setTimeout(() => $('#back').focus(), 300);
}
function closePage() {
  page.classList.remove('on'); page.setAttribute('aria-hidden', 'true');
  try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
}
$('#back').addEventListener('click', closePage);
addEventListener('keydown', e => { if (e.key === 'Escape') { if ($('#drawer').classList.contains('on')) closeDrawer(); else if (page.classList.contains('on')) closePage(); } });

/* ---------- inquiry list ---------- */
const toastEl = $('#toast'); let tt;
function toast(m) { toastEl.textContent = m; toastEl.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => toastEl.classList.remove('on'), 1700); }
function toggleCart(slug) {
  if (cart.has(slug)) { cart.delete(slug); toast(`${bySlug[slug].d.name} removed`); }
  else { cart.set(slug, 25); toast(`${bySlug[slug].d.name} added · 300 pairs`); }
  $('#count').textContent = cart.size; renderDrawer();
}
function renderDrawer() {
  const b = $('#dBody');
  if (!cart.size) { b.innerHTML = `<div class="empty">Open any shoe and tap “Add to inquiry list”. Or just send the form for the full FW26 line sheet.</div>`; return; }
  b.innerHTML = [...cart.keys()].map(s => { const d = bySlug[s].d; return `<div class="row"><span class="t"><img src="shoes/${d.img}.webp" alt=""></span><span><b>${d.name}</b><small>25 cases · 300 pairs · ${SIZE_LABEL[d.line]}</small></span><button class="btn btn-ghost" data-rm="${s}" aria-label="Remove ${d.name}" style="width:38px;height:38px;padding:0">${icon('close')}</button></div>`; }).join('');
  b.querySelectorAll('[data-rm]').forEach(x => x.addEventListener('click', () => toggleCart(x.dataset.rm)));
}
function openDrawer() { renderDrawer(); $('#drawer').classList.add('on'); $('#scrim').classList.add('on'); $('#drawer').setAttribute('aria-hidden', 'false'); }
function closeDrawer() { $('#drawer').classList.remove('on'); $('#scrim').classList.remove('on'); $('#drawer').setAttribute('aria-hidden', 'true'); }
$('#openList').addEventListener('click', openDrawer); $('#closeD').addEventListener('click', closeDrawer); $('#scrim').addEventListener('click', closeDrawer);
$('#dForm').addEventListener('submit', e => {
  e.preventDefault(); const f = e.target; if (!f.checkValidity()) { f.reportValidity(); return; }
  const n = cart.size;
  $('#dBody').innerHTML = `<div class="empty" style="color:var(--ink)"><b style="font-size:16px">Inquiry ready</b><br>${f.company.value}: ${n ? n + ' style' + (n > 1 ? 's, ' + n * 300 + ' pairs' : ', 300 pairs') : 'full line sheet'}. Pricing goes to ${f.email.value}.<br><br><span style="color:var(--muted);font-size:12px">Demo form: connect it to your inbox or CRM to receive inquiries.</span></div>`;
});
renderDrawer();

/* exposed for quick checks from the console */
window.showroom = { openPage, closePage, flyTo, views: VIEWS };
